package SuleymanHocaIng;

import java.util.Scanner;

public class Scannr {

    public static void main(String[] args) {

        //Example 1: Get the initials of name which contains first name and last name
        //           Tom Hanks ==> TH

        Scanner input = new Scanner(System.in);
        System.out.println("Enter your first and the last name..");
        String fullName = input.nextLine();

        char first = fullName.charAt(0);
        char last  = fullName.split(" ")[1].charAt(0);
        System.out.println(first +"-"+last);

        //charAt(0); tum isimden ilk karakteri yani 0. indexteki alir.
        //char last  = fullName.split(" ")[1].charAt(0);  Bu ifadeki split metni bosluktan ikiye boler
        //[0] 0. index metni ve [1] 1. index metni olarak
        //Bu kodla aradaki bosluktan ikiye bolunerek 2.kismin ilk karakterini aldik



    }

}

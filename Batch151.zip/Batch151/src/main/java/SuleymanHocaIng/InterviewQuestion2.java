package SuleymanHocaIng;

public class InterviewQuestion2 {

    public static void main(String[] args) {

        //Example 1: Type to swap the integers
        //       a=12 and b=15 ==> a=5 and b=12

        int a = 12;
        int b = 15;
        System.out.println("first:" + a+"-"+b); //12-5

        //temp gecici

        int temp = 0;
        //1.Step
        temp = a;
        //2.Step
        a = b;
        //3.Step
        b=temp;

        System.out.println("last:" + a+"-"+b);//5-12

        //2. way: Do not create 3rd variable

        int x =12;
        int y = 5;
        System.out.println("ilk hali:"+ x+ "-" +y);

        x= x+y; //x=17
        y= x-y; //17-5=12 ==> y=12
        x= x-y; //17-12=5 ==> x=5
        System.out.println("x"+ x);
        System.out.println("y"+ y);

        System.out.println("son hali:"+ x+ "-" +y);














    }
}

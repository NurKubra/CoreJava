package SuleymanHocaIng;

public class StrngManpltn2 {
    public static void main(String[] args) {

        //Example 1: Get teh first 4 characters from a String and convert them to lower cases
        //          Albania ==> Alba == > alba

        String a ="Albania";
        String t = a.substring(0,4).toLowerCase();
        System.out.println("t = " + t); //alba


        //Example 2: Check if two String are same or not? //iki string in esit olup olmadigna bak

        String r= "Java";
        String u= "java";

        boolean sameEqualSign = r==u; //false
        System.out.println(sameEqualSign); //false because values and adresses are different


        boolean same = r.equals(u);
        System.out.println("same = " + same); //false

        boolean sameIgnoreCases = r.equalsIgnoreCase(u);
        System.out.println("sameIgnoreCases = " + sameIgnoreCases); //true

        //Bir metni başka bir metinle karşılaştırmak için equals ya da equalsIgnoreCase metodlarını kullanabilirsiniz.
        // equalsIgnoreCase metodu, karşılaştırılan metni öncelikle küçük harflere çevirir ve ardından karşılaştırma yapar.
        // Böylelikle büyük-küçük harf durumundan doğacak sorunun önüne geçilmiş olur.

        //== > Java will two things check 1) Values(in Heap memory) and 2)Adresses(in satck memory)
        //yani hem values olarak hem de adresleri esit mi diye bakar ama String s1 ve s2 icin
        //equels > Java will check the only values

        //Question : why we do not use "==" to compare Strings?  (Neden matematiksel esittiri kullanmadik?)

        String s1= "TechPro";
        String s2= "TechPro";

        boolean r1= s1==s2;
        System.out.println("r1 = " + r1); //true

        boolean r2 = s1.equals(s2);
        System.out.println("r2 = " + r2);//true

        //Burda



    }
}

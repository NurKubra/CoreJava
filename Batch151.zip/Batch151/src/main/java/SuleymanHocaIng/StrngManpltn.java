package SuleymanHocaIng;

import java.util.Scanner;

public class StrngManpltn {

    public static void main(String[] args) {
        //Example 1: Get the full name of the user and make all characters in upper cases

        Scanner input = new Scanner(System.in);
        System.out.println("Enter your first and the last name.."); //tOM hANKS
        String fullName = input.nextLine().toUpperCase();

        //toUpperCase() method converts all characters ti upper cases
        System.out.println(fullName); //TOM HANKS

        //Example 2: Get the full name of the user, make all characters in upper cases, and remove spaces
        //           from the beginning and from the end.
        // ismin basindaki ve sonundaki bosluk karakterini silmek istiyoruz

        System.out.println("Enter your first and the last name.."); //   Tom Hanks
        String name  = input.nextLine().toUpperCase().trim();  //trim bosluklari sil //Method Chain
        System.out.println(name); //TOM HANKS

        //trim() method removes th "space" characters from the beginning and from the end.
        //trim() method does not touch spaces in the middle


        //Example 3: Get a String from user, then count the number of characters in the String

        System.out.println("Enter a String...");  //Germany // United States America
        String s = input.nextLine();
        int numOfChars = s.length();
        System.out.println("numOfChars = " + numOfChars); //7  //21

        //length() method gives you the number of characters in a String










    }
}

package slaytsorubankasi.ifelsestatement;

import java.util.Scanner;

public class Q02 {

    public static void main(String[] args) {

        //Soru 2) Kullanicidan bir karakter girmesini isteyin ve girilen karakterin harf olup
        //    olmadigini yazdirin

        Scanner scan = new Scanner(System.in);
        System.out.println("Lütfen bir karakter giriniz..");
        char ch = scan.next().toLowerCase().charAt(0);

        if (ch >= 'a' && ch <= 'z') {
            System.out.println("Girilen karakter harftir..");
        } else if (ch >= '0' && ch <= '9') {
            System.out.println("Rakamdir");
        } else {
            System.out.println("Girilen karakter harf degildir..");
        }




    }

}

package slaytsorubankasi.ifelsestatement;

public class Q10 {
    public static void main(String[] args) {
        //Soru 10) Interview Question
        //    Kullanicidan artik yil olup olmadigini kontrol etmek icin yil girmesini isteyin.
        //    Kural 1: 4 ile bolunemeyen yillar artik yil
        //    degildir
        //    Kural 2: 4'un kati olmasina ragmen 100 ile bolunebilen yillardan sadece 400'un kati olan yillar artik yildir



    }
}

package slaytsorubankasi.ifelsestatement;

import java.util.Scanner;

public class Q05 {

    public static void main(String[] args) {
        // Soru 5) Kullanicidan gun ismini yazmasini isteyin. Girilen isim gecerli bir gun ise gun
        //    isminin 1.,2. ve 3.harflerini ilk harf buyuk diger ikisi kucuk olarak yazdirin,
        //    gun ismi gecerli degilse "Gecerli gun ismi giriniz" yazdirin
        //
        Scanner scan = new Scanner(System.in);
        System.out.println("Lütfen bir gun ismi giriniz..");
        String gun =scan.next().toLowerCase();
        boolean x = (gun.equals("pazartesi")
                || gun.equals("sali")
                || gun.equals("carsamba")
                || gun.equals("persembe")
                || gun.equals("cuma")
                || gun.equals("cumartesi")
                || gun.equals("pazar"));

        if (x){
           //1. yol System.out.println("" + gun.toUpperCase().charAt(0) + gun.charAt(1) + gun.charAt(2));
           //2.yol System.out.println(gun.substring(0,1).toUpperCase() + gun.substring(1,2)+ gun.substring(2,3));
            System.out.println(gun.substring(0,1).toUpperCase() + gun.substring(1,3));  //3.yol


        }else{
            System.out.println("Gecerli bir gun ismi giriniz..");
        }
    }
}

package slaytsorubankasi.ifelsestatement;

import java.util.Scanner;

public class Q04 {

    public static void main(String[] args) {

        // Soru 4) Kullanicidan bir ucgenin uc kenar uzunlugunu alin eger uc kenar uzunlugu
        //    birbirine esit ise ekrana "Eskenar ucgen" yazdirin. Diger durumlarda ekrana
        //    "Eskenar degil" yazdirin



        Scanner scan = new Scanner(System.in);
        System.out.println("Lütfen birinci kenari giriniz..");
        int bir =scan.nextInt();
        System.out.println("Lütfen ikinci kenari giriniz..");
        int iki =scan.nextInt();
        System.out.println("Lütfen ucuncu kenari giriniz..");
        int uc =scan.nextInt();

        if(bir == iki && iki == uc){
            System.out.println("Eskenar ucgen..");

        }else {
            System.out.println("Eskenar degil");
        }


    }
}

package slaytsorubankasi.ifstatement;

import java.util.Scanner;

public class Q05 {
    public static void main(String[] args) {

        // Soru 5) Kullanicidan bir gun alin eger gun "Cuma" ise ekrana "Muslumanlar icin kutsal
        //    gun" yazdirin. "Cumartesi" ise ekrana "Yahudiler icin kutsal gun" yazdirin. "Pazar"
        //    ise ekrana "Hiristiyanlar icin kutsal gun" yazdirin.

        Scanner scan = new Scanner(System.in);
        System.out.println("Lutfen bir gun giriniz..");
        String gun = scan.next();

        if (gun.equalsIgnoreCase("Cuma")){
            System.out.println("Muslumanlar icin kutsal gun..");
        }else if (gun.equalsIgnoreCase("Cumartesi")){
            System.out.println("Yahudiler icin kutsal gun..");
        } else if (gun.equalsIgnoreCase("Pazar")) {
            System.out.println("Hristiyanlar icin kutsal gun..");
        } else {
            System.out.println("Kutsal bir gun girmediniz..");
        }

        //2.yol switch case (buyuk ya da kucuk harfe dikkat edilmeli )
        switch (gun){

            case "cuma":
                System.out.println("Muslumanlar icin kutsal gun..");
                break;
            case "cumartesi":
                System.out.println("Yahudiler icin kutsal gun..");
                break;
            case "pazar":
                System.out.println("Hristiyanlar icin kutsal gun..");
                break;
            default:
                System.out.println("Gecersiz islem");
        }

        //3.yol  for loop ile yazdik bu sayede bir seferde butun sorulara ard arda cevap verebiliriz.
        for (int i =0 ; i<4;i++) {
            System.out.println("Lutfen bir gun giriniz..");
            String gun2 = scan.next();

            if (gun2.equalsIgnoreCase("Cuma")) {
                System.out.println("Muslumanlar icin kutsal gun..");
            } else if (gun2.equalsIgnoreCase("Cumartesi")) {
                System.out.println("Yahudiler icin kutsal gun..");
            } else if (gun2.equalsIgnoreCase("Pazar")) {
                System.out.println("Hristiyanlar icin kutsal gun..");
            } else {
                System.out.println("Kutsal bir gun girmediniz..");
            }
        }
    }
}

package slaytsorubankasi.ifstatement;

import java.util.Scanner;

public class Q03 {
    public static void main(String[] args) {

        //Soru 3) Kullanicidan gun ismini alin ve haftaici veya hafta sonu oldugunu yazdirin
        //    Ornek: gun=Pazar output = "Hafta sonu"
        //    gun=Sali output = "Hafta ici"
        //    *** String icin equals method'unu kullanin
        //    *

        Scanner scan = new Scanner(System.in);
        System.out.println("Lutfen gun ismi giriniz..");
        String gun = scan.next().toLowerCase();

        //1.yol
        if(gun.equals("pazartesi") || gun.equals("sali") || gun.equals("carsamba") || gun.equals("persembe")
        || gun.equals("cuma")){
            System.out.println("Hafta Ici");
        } else if (gun.equals("cumartesi") || gun.equals("pazar")) {
            System.out.println("Hafta Sonu");
        }else {
            System.out.println("Gecersiz islem");
        }




    }
}

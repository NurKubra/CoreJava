package slaytsorubankasi.ifstatement;

import java.util.Scanner;

public class Q01 {
    public static void main(String[] args) {
        // Soru 1) Kullanicidan bir tamsayi isteyin ve sayinin tek veya cift oldugunu yazdirin


        Scanner scan =new Scanner(System.in);
        System.out.print("lütfen bir tamsayi giriniz: ");
        int sayi = scan.nextInt();

        if (sayi%2==0){
            System.out.println("Cift sayidir");
        }else {
            System.out.println("Tek sayidir");
        }

        scan.close();




    }
}

package slaytsorubankasi.ifstatement;

import java.util.Scanner;

public class Q04 {

    public static void main(String[] args) {
        //Soru 4) Kullanicidan dikdortgenin kenar uzunluklarini isteyin ve dikdortgenin kare olup
        //    olmadigini yazdirin

        Scanner scan = new Scanner(System.in);
        System.out.println("Lütfen ilk kenar giriniz..");
        System.out.println("Lütfen ikinci kenar giriniz..");
        int ilk  = scan.nextInt();
        int ikinci  = scan.nextInt();

        //1.yol
        if (ilk == ikinci) {
            System.out.println("Kare");
        }else {
            System.out.println("Kare degildir");
        }

        //2.yol-Ternary
        String result = ilk == ikinci ? "Kare" : "Kare degil" ;




    }
}

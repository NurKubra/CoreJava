package slaytsorubankasi.ifstatement;

import java.util.Scanner;

public class Q02 {

    public static void main(String[] args) {
        
        // Soru 2) Kullanicidan gun isimlerinden birinin ilk harfini isteyin ve o harfle baslayan gun
        //        isimlerini yazdirin
        //        Ornek: ilkHarf=P output = "Pazar, Pazartesi veya Persembe"
        //        ilkHarf=S output = "Sali"
        //        *** Buyuk kucuk harf problem olmamasi icin toUpperCase methodunu kullanin


        Scanner scan= new Scanner(System.in);
        System.out.println("Lütfen gun isimlerinden birinin ilk harfini giriniz..");
        String ilkHarf = scan.next().toUpperCase();

        scan.close();
        //1.yol
        if (ilkHarf.equals("P")){    //IlkHarf == "P" kabul etmiyor  ==> if in icinde String bir ifade icin == yerine equals kullanilir!!
                                        //IlkHarf.equals("P") kullanilir.
            System.out.println("Pazar, Pazartesi, Persembe");
        }else if (ilkHarf.charAt(0)=='S') {
            System.out.println("Sali");
        }else if (ilkHarf.charAt(0)=='C') {
            System.out.println("Cuma, Cumartesi, Carsamba");
        }else {
            System.out.println("Gecersiz Islem");
        }

        //2.yol
        Scanner scan2= new Scanner(System.in);
        System.out.println("Lütfen gun isimlerinden birinin ilk harfini giriniz..");
        String ilkHarf2 = scan2.next().toUpperCase();

        switch (ilkHarf2){
            case "P":
                System.out.println("Pazar, Pazartesi, Persembe");
                break;
            case "S":
                System.out.println("Sali");
                break;
            case "C":
                System.out.println("Cuma, Cumartesi, Carsamba");
                break;
            default:
                System.out.println("Gecersiz Islem");

        }
        scan2.close();
    }
}

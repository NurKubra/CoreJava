package javaders.day15loopsarrays;

public class Arrays03 {

    public static void main(String[] args) {
        //Kullanicinin coklu datayi bir array'a yerlestirebilmesi icin gereken kodu yaziniz


    }
}

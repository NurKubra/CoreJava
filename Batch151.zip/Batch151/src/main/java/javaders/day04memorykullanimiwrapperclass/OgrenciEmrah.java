package javaders.day04memorykullanimiwrapperclass;

public class OgrenciEmrah {

    //Burda sadece pasif ve aktif özellikler olusturuduk. Main method yok. Runner da main methodla calistircagiz.


    //Pasif özellikler
    public String name = "Emrah";
    public String brans= "QA";
    public int yas = 25;


    public void study() {

        System.out.println("Emrah bey gunluk duzenli calisir..");
    }

    public void derseDevam(){

        System.out.println("Emrah bey düzeli derslere devam eder...");
    }

}

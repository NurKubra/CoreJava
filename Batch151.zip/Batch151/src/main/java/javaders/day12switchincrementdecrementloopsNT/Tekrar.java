package javaders.day12switchincrementdecrementloopsNT;

public class Tekrar {

    public static void main(String[] args) {


    }
}

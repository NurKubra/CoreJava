package practice.day_01_practice;

public class C02_Ascii {


    // Rakam kullanmadan 65, 66, 67, 68, 69, 70 sayilarinin toplamını bulunuz
    //Ascii degerlerden faydalanarak

    public static void main(String[] args) {

        System.out.println((int)'A'+(int)'B'+(int)'C'+(int)'D'+(int)'E'+(int)'F');

        // char'i type casting ile int 'e ceviriyoruz!!

    }
}

package simurg01.methodstringifswitch;

import java.util.Scanner;

public class Q02_KelimeTerstenYazmaIkinci {


    // kullanicidan bir kelime isteyin
    // eger kelime 3 harften kisa ise "kelime cok kisa" yazdirin
    // eger kelime 3,4 veya 5 harfli ise harf sayisini ve
    // kelimenin tersten yazilisini yazdirin
    // eger 5 harften uzunsa "kelime cok uzun" yazdirin //Method kullanilmali


    public static void main(String[] args) {


        Scanner scan = new Scanner(System.in);
        System.out.println("Lutfen Kelime giriniz..");
        String kelime = scan.nextLine();

        terstenyazdir(kelime);
    }

    private static void terstenyazdir(String kelime) {
        String tersKelime ="";

        if(kelime.length()<3){
            System.out.println("Kelime cok kisa");

        }else if (kelime.length()>=3 && kelime.length()<6){
            for (int i = kelime.length()-1;  i>-1  ; i--){
                tersKelime = tersKelime + kelime.charAt(i);
                //System.out.println(tersKelime);
            }
            System.out.println("tersKelime = " + tersKelime);
            System.out.println("harf sayisi = " + kelime.length());

        }else {
            System.out.println("kelime cok uzun");
        }
    }
}

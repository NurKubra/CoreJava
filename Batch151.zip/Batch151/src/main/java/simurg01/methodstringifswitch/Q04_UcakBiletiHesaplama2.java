package simurg01.methodstringifswitch;

public class Q04_UcakBiletiHesaplama2 {
    public static void main(String[] args) {


    }
}

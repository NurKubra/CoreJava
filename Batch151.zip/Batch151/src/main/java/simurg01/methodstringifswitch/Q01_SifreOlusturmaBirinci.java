package simurg01.methodstringifswitch;

import java.util.Scanner;

public class Q01_SifreOlusturmaBirinci {

    public static void main(String[] args) {

        // Soru-1
        // Kullanicidan bir sifre girmesini isteyin.
        // Asagidaki sartlari sagliyorsa "Sifre basari ile tanimlandi",
        // sartlari saglamazsa "Islem basarisiz,Lutfen yeni bir sifre girin" yazdirin
        // - Ilk harf buyuk harf olmali
        // - Son harf kucuk harf olmali
        // - Sifre bosluk icermemeli
        // - Sifre uzunlugu en az 8 karakter olmali
        // bu 4 kontrolu method ile yapin

        Scanner scan=new Scanner(System.in);
        System.out.println("Lütfen" +
                "\nilk harfi buyuk," +
                "\nSon harfi kucuk," +
                "\nbosluk icermeyen" +
                "\n8 karakter uzunlugunda bir sifre giriniz?");
        String pass= scan.nextLine();
        checkPassword(pass);

    }

        private static void checkPassword(String example) {

            boolean uppercasePass = Character.isUpperCase(example.charAt(0));
            boolean lowercasePass = Character.isLowerCase(example.charAt(example.length() - 1));
            boolean spacePass = !example.contains(" ");
            boolean lengthPass = example.length() >= 8;
            if (uppercasePass && lowercasePass && spacePass && lengthPass) {
                System.out.println("Sifre basari ile tanimlandi");
            } else {
                System.out.println("Islem basarisiz,Lutfen yeni bir sifre girin");
            }

        }

}

package simurg01.methodstringifswitch;

import java.util.Scanner;

public class Q03_HesapMakinasi {

    public static void main(String[] args) {

        /*
        method ve switch case kullanarak 4 islemli basit bir hesap makinesi olusturun

        1
        2
        (+,-,*,/)
         */


        Scanner input = new Scanner(System.in);
        System.out.println("1.Sayi");
        double birinciSayi= input.nextDouble();

        System.out.println("2.Sayi");
        double ikinciSayi =input.nextDouble();

        System.out.println("Yapacaginiz islemi secin");
        char islem = input.next().charAt(0);

        double sonuc = islemYap(birinciSayi, ikinciSayi, islem); //method Creation
        System.out.println(birinciSayi+" "+islem +" "+ ikinciSayi+ "=" + sonuc);  //2 - 2 = 0


    }

    private static double islemYap(double birinciSayi, double ikinciSayi, char islem) {

        switch (islem) {
            case '+':
                return birinciSayi + ikinciSayi;

            case '-':
                return birinciSayi - ikinciSayi;

            case '*':
                return birinciSayi * ikinciSayi;

            case '/':
                return birinciSayi / ikinciSayi;

            default:
                System.out.println("Hata: Gecersiz islem");

                return islem;  // buraya islem, 0, birinciSayi, ikinciSayi}

        }
    }
}

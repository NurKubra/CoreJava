package simurg01.methodstringifswitch;

import java.util.Scanner;

public class Q03_HesapMakinesi2 {


    public static void main(String[] args) {

          /*
        method ve switch case kullanarak 4 islemli basit bir hesap makinesi olusturun
        1
        2
        (+,-,*,/)
         */

        Scanner scan = new Scanner(System.in);
        System.out.println("Birinci sayi :");
        double birinci = scan.nextDouble();

        System.out.println("Ikinci sayi: ");
        double ikinci = scan.nextDouble();

        System.out.println("Yapmak istediginiz islemi secin (+,-,*,/)");
        char islem = scan.next().charAt(0);

        double sonuc= 0; //icine herhangi bir deger atadik
        switch (islem){
            case'+':
                sonuc = birinci +ikinci;
                break;
            case'-':
                sonuc = birinci- ikinci;
                break;
            case '*':
                sonuc= birinci * ikinci;
                break;
            case '/':
                sonuc =birinci/ ikinci;
                break;
            default:
                System.out.println("Hatali giris");

        }

        System.out.println("Sonuc: "+ sonuc);  //sonucu disarida yazdiriyoruz.
        scan.close();
        //Scanner objesinin kapladigi alani serbest birakir
        //bunu yapmak intelijin yavas calismasini engeller


    }
}

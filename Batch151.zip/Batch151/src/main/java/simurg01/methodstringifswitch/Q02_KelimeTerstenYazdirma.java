package simurg01.methodstringifswitch;

import java.util.Scanner;

public class Q02_KelimeTerstenYazdirma {

    public static void main(String[] args) {



        // kullanicidan bir kelime isteyin
        // eger kelime 3 harften kisa ise "kelime cok kisa" yazdirin
        // eger kelime 3,4 veya 5 harfli ise harf sayisini ve
        // kelimenin tersten yazilisini yazdirin
        // eger 5 harften uzunsa "kelime cok uzun" yazdirin //Method kullanilmali


        Scanner scan = new Scanner(System.in);
        System.out.println("Lütfen bir kelime giriniz");
        String kelime = scan.next();
        int harfSayisi = kelime.length();  //harf sayisi

        if (harfSayisi<3){
            System.out.println("Kelime cok kisa");
        }else if(harfSayisi==3){
            ucHarfiTersCevir(kelime);
        }else if(harfSayisi==4){
            dortHarfTersCevir(kelime);
        }else if(harfSayisi==5){
            besHarfTersCevir(kelime);
        }else{
            System.out.println("Kelime cok uzun");
        }

    }
    /*
     a b c d e
     0 1 2 3 4
     */

    private static void besHarfTersCevir(String kelime) {
        String tersKelime = kelime.substring(4)+
                            kelime.substring(3,4)+
                            kelime.substring(2,3)+
                            kelime.substring(1,2)+
                            kelime.substring(0,1);
        System.out.println("Kelimenin harf sayisi 5");
        System.out.println(tersKelime);

    }

    private static void dortHarfTersCevir(String kelime) {
        String tersKelime =kelime.substring(3)+
                           kelime.substring(2,3)+
                           kelime.substring(1,2)+
                           kelime.substring(0,1);
        System.out.println("Kelimenin harf sayisi 4");
        System.out.println(tersKelime);
    }

    private static void ucHarfiTersCevir(String kelime) {
        String tersKelime = kelime.substring(2)+
                            kelime.substring(1,2)+
                            kelime.substring(0,1);
        System.out.println("Kelimenin harf sayisi 3");
        System.out.println(tersKelime);

    }
}

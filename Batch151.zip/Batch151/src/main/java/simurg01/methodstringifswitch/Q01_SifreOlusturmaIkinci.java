package simurg01.methodstringifswitch;

import java.util.Scanner;

public class Q01_SifreOlusturmaIkinci {


    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Lütfen bir sifre giriniz...");
        String sifre =input.nextLine();

        //4 ayri obje olusturuyoruz

        boolean ilkHarf= ilkHarfKontrol(sifre);
        boolean sonHarf= sonHarfKontrol(sifre);
        boolean boslukKontrol= boslukKontrol(sifre);
        boolean uzunlukKontrol= uzunlukKontrol(sifre);
        if (ilkHarf && sonHarf && boslukKontrol &&uzunlukKontrol ){
            System.out.println("Basarili sifre girisi");
        }else {
            System.out.println("Islem basarisiz, Lutfen yeni bir sifre girin");
        }

    }

    private static boolean uzunlukKontrol(String sifre) {
        //if'in icinde kullanilcak degerler if in disinda tanimlanmali!! if blogu icinde tanimlananlar kullanilmaz.
        //deger atamasini method icinde yapmaliyiz
        //Burda b1 icin gecici bir deger giriyoruz.

        boolean b1 = false;
        // boolean b1=false;
        if(sifre.length()>=8){
            b1=true;
            System.out.println("Sifre en az 8 karakter olmali");
            b1=false;
        }
        return b1;
    }

    private static boolean boslukKontrol(String sifre) {
        boolean b2;  //atamayi bu sekilde de gerceklestirebiliriz.
        //boolean b2= true; //geicici deger false da
       if (!sifre.contains(" ")){
           b2=true;
       }else {
           b2=false;
       }
        return b2;
    }

    private static boolean sonHarfKontrol(String sifre) {
        boolean b3 = false;

        char sonHarf =sifre.charAt(sifre.length()-1);
        if (sonHarf>='a' && sonHarf<='z'){
            b3=true;
        }else {
            System.out.println("Sifrenizin son harfi kucuk olmali");
        }
        return b3;
    }

    private static boolean ilkHarfKontrol(String sifre) {
        boolean b4 = false;
        char ilkHarf = sifre.charAt(0);
        if (ilkHarf>='A' && ilkHarf<='Z'){
            b4=true;
        }else {
            System.out.println("Sifrenizin ilk harfi buyuk olmalidir");
        }
        return b4;
    }
}

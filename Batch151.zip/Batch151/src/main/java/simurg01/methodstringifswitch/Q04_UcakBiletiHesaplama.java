package simurg01.methodstringifswitch;

import java.util.Scanner;

public class Q04_UcakBiletiHesaplama {


    public static void main(String[] args) {

        /*
        Mini Proje. UcakBiletiHesaplama

        //gidecegi mesafe, km basi birim fiyati: 0.10$
        //yolcu 12 yasindan kucukse toplam fiyata %50 indirim
        //12 ve 24 arasinda ise %20 indirim
        //65 yasindan buyukse %30 indirim
        //gidis-dönus bileti alirsa %20 indirim
        //Bu kosullara gore ucak bileti fiyati hesaplayan program yaziniz

        (Bir tane indirim methodu() ile cözum tavsiye edilir)

         */

        Scanner input =new Scanner(System.in);
        System.out.println("Lütfen yasinizi giriniz..");
        int yas = input.nextInt();

        System.out.println("Lütfen Km giriniz..");
        double mesafe = input.nextInt();

        System.out.println("Lütfen tek yön icin 1 \n gidis donus icin 2 giriniz: ");
        int type = input.nextInt();

        biletHesapla(yas,mesafe,type);

    }

    private static void biletHesapla(int yas, double mesafe, int type) {

        double fiyat=0;
        fiyat = mesafe *0.10;  //km basi birim fiyati:0.10$

        if (type == 2) {
            fiyat=fiyat-(fiyat*20/100);
        }
        if (yas<13){
            indirimYap(50,fiyat);
        }else if (yas>12 && yas<24){
            indirimYap(20,fiyat);
        }else if (yas>25 && yas<65){
            indirimYap(0,fiyat);
        }else if(yas>65){
            indirimYap(30,fiyat);
        }
    }

    private static void indirimYap(int yuzde,double fiyat) {

        fiyat =fiyat- fiyat * yuzde/100;
        System.out.println("Odemeniz gereken tutar:" + fiyat);

    }

}

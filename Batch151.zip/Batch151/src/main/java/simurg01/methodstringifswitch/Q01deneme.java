package simurg01.methodstringifswitch;

import java.util.Scanner;

public class Q01deneme {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Lütfen" +
                "\nilk harfi buyuk," +
                "\nSon harfi kucuk," +
                "\nbosluk icermeyen" +
                "\n8 karakter uzunlugunda bir sifre giriniz?");
        String password = scan.nextLine();

        checkPass(password);

    }

    private static void checkPass(String password) {
        boolean upperCasePass = Character.isUpperCase(password.charAt(0));
        boolean lowerCase = Character.isLowerCase(password.charAt(password.length()-1));
        boolean spacePass = !password.contains(" ");
        boolean lengthPass = password.length()>=8;

        if (upperCasePass && lowerCase && spacePass && lengthPass){
            System.out.println("Sifre basari ile tanimlandi");

        }else {
            System.out.println("Islem basarisiz, lütfen yeni bir sifre girin");
        }



    }


}

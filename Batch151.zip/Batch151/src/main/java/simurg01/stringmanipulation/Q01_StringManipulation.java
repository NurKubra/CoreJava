package simurg01.stringmanipulation;

import java.util.Scanner;

public class Q01_StringManipulation {

    //Ex1
    //1)Kullanicidan isim ve soyisim bilgisi aliniz
    //2)Kullanicidan dogum yilini aliniz(int)
    //3)isim ve soyisimlerin ilk iki karakterini aliniz. (Oguzhan Parlak: ogpa)
    //4)Dogum yilimizin son iki hanesini alin
    //5)Aldiginiz datalari birlestirin ve sonuna "@gmal.com" ekleyin --> ogpa92@gmail.com(String)

    public static void main(String[] args) {

        //Ex1
        //1)Kullanicidan isim ve soyisim bilgisi aliniz
        Scanner scan = new Scanner(System.in);   //(scanner, scan, input)
        System.out.println("Lütfen isim giriniz..:");
        String name = scan.nextLine();

        System.out.println("Lütfen soyisim giriniz..:");
        String surname = scan.nextLine();

        //2)Kullanicidan dogum yilini aliniz(int)
        System.out.println("Lütfen dogum yilinizi giriniz..:");
        int num = scan.nextInt();

        //3)isim ve soyisimlerin ilk iki karakterini aliniz. (Oguzhan Parlak: ogpa)
        char firstCharName = name.charAt(0);
        char secondCharName = name.charAt(1);
        String firstTwoCharName = Character.toString(firstCharName).toLowerCase() +
                Character.toString(secondCharName).toLowerCase();     //char seklinde olan datayi String'e cevirdik.
        System.out.println(firstTwoCharName);


        char firstCharSurname = surname.charAt(0);
        char secondCharSurname = surname.charAt(1);
        String firstTwoCharSurname = Character.toString(firstCharSurname).toLowerCase() +
                Character.toString(secondCharSurname).toLowerCase();
        System.out.println(firstTwoCharSurname);


        //4)Dogum yilimizin son iki hanesini alin
        String stringYear = Integer.toString(num);
        System.out.println(stringYear);                                   //Int data type'ini String'e cevirdik
        String lastTwoDigit = stringYear.substring(2);
        System.out.println(lastTwoDigit);

        //5)Aldiginiz datalari birlestirin ve sonuna "@gmal.com" ekleyin --> ogpa92@gmail.com
        System.out.println("" + (firstTwoCharName + firstTwoCharSurname + lastTwoDigit) + "@gmail.com");

    }
}

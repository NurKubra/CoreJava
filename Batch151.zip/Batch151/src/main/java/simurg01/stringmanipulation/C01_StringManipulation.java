package simurg01.stringmanipulation;

import java.util.Locale;

public class C01_StringManipulation {
     /*
     str,num,nummer,digit,i,ch kullanilabilir.
      */
    public static void main(String[] args) {


        //1) toUpperCase() :1)Verilen bir String'deki tum harfleri buyuk harf yapar
        //                  2)String bir data döndürür.

        String str="Simurg";
        System.out.println(str.toUpperCase());  //SIMURG
        System.out.println(str.toUpperCase(Locale.forLanguageTag("en")));  // ing olmayan karakterleri ing cevirir
        System.out.println(str.toUpperCase(Locale.ENGLISH));
        System.out.println(str.toUpperCase(Locale.forLanguageTag("tr")));  // türkce karaktere cevirir


        //2) toLowerCase() :1)Verilen bir String'deki tum harfleri kucuk harf yapar
        //                  2)String bir data döndürür.

        String str1 ="INTERNATIONAL";
        System.out.println(str1.toLowerCase()); //international
        System.out.println(str1.toLowerCase(Locale.ENGLISH)); //international
        System.out.println(str1.toLowerCase(Locale.forLanguageTag("tr"))); // turkce karaktere cevirir


        //3) charAt()   :1)istenen indexteki karakteri getirir
        //               2) char dondurur.
        //               3) 0'dan baslar
        //               4) charAt() ---> ilk karakter alir
        //               5)charAt()(length()-1)--> son karakter
        //               Not : Eger method'da index olarak maximum indexten buyuk bir sayi kullaninirlsa
        //                  Java hata verir.
        /*
                        String s = "Simurg";
                                    012345 --->index
                                    123456--> length() //uzunluk

         */
        String str2 ="Merhaba";
        //verilen String'in ilk harfini buyuk yapiniz

        char ch =str2.toLowerCase().charAt(0); //m
        System.out.println(ch);                //m

        //verilen string'in son karakterini buyuk harfle yazdirin
        char ch1 =str2.toUpperCase().charAt(str2.length()-1); // dinamik kod olmasi icin bu sekilde yazdik
        System.out.println(ch1);       //A


        //4) length() : 1)Verilen String'deki karakter sayisini döndürür (bosluk da dahil olmak uzere)
        //              2)int bir deger dondurur.

        String str3 = "Java ogreniyoruz";
        System.out.println(str3);  //

        //5) substring() :1)Index kullanarak verilen String'in istenilen parcasini almamizi saglar
        //                2)String bir deger dondurur.
        //                3)Baslangic indexi dahil bitis indexi haric döndürür
        //                4)Tek bir deger gireresek o indexten itibaren String sonuna kadar yazdirir.

        System.out.println(str3.substring(5, 9));  // greniyoruz
        System.out.println(str3.substring(6));

        String stry = "Java OOP konsepti kullanir";
        System.out.println(stry.substring(0));  //Java OOP konsepti kullanir
        System.out.println(stry.substring(10));  //onsepti kullanir
        System.out.println(stry.substring(26));  //
        // System.out.println(stry.substring(29));  //hata verir cunku toplam karalter sayisi 26
        System.out.println("Toplam karakter sayisi: "+stry.length());  //26


        //6) startsWith() : 1)Verilen String'in istenen karakter(ler) ile baslayip baslamadigini kontrol eder.
        //                  2)Bize boolean bir data döndürür (True ya da false)
        //                  3)Sorguladigimiz datanin buyuk ya da kucuk harf olmasi onemlidir.
        //                   i)Parametre String olabilir
        //                  ii)Parametre kelime olabilir
        //                 iii)Belirli karakterden sonrasi olabilir

        String strx = "Calisirsaniz, Java ogrenmek cok kolay";
        //                   i)Parametre String olabilir
        System.out.println(strx.startsWith("C"));                     //true
        //                  ii)Parametre kelime olabilir
        System.out.println(strx.startsWith("Calis"));                 //true
        //                 iii)Belirli karakterden sonrasi olabilir
        System.out.println(strx.startsWith("s",4));       //true
        System.out.println(strx.startsWith("Java",14));   //true

        System.out.println(str3.startsWith("Java ogren"));   //true


        //7) contains ()
        /*
        1-String olmali, char olmamali
        2-olmayan bir karakter sorgulanirsa sonuc-1
        3-parametre metin olabilir
        4-return type boolean'dir
         */

        String simple ="Techproeducation 2021";
        boolean first1= simple.contains("e");
        System.out.println(first1);

        boolean first2= simple.contains("2023");
        System.out.println(first2);

        boolean first3 = simple.contains("f");
        System.out.println(first3);

        //8) endsWith()
        /*
        Verilen String'in verilen karakter ya da karakterler ile bitip bitmedigini kontrol eder.
        1-return type boolean
        2-String olmalidir, char olmamalidir
        3-parametre olarak kelime de aratabiliriz
        4-kucuk buyuk harf duyarlidir!!
         */

        String basic = "Java Script";
        boolean second = basic.endsWith("t");
        System.out.println(second);

        boolean second2 = basic.endsWith("script");
        System.out.println(second2);  //false buyuk harf olmali


        //9)replace()
        /*
        Verilen String'deki istenen karakterleri yeni karakterle degistirir.
        1-String ve char kullanilabilir !!
        2-Birden fazla karakter icin cift tirnak kullanilmali
        3-return type string olmalidir.
        4-Degistirmek istediklerimizin data type'i ayni olmalidir. String ile char ayni anda olmaz,
        String-String ya da char-char olabilir.
         */

        String s1= "Türkiye'nin baskenti Ankara'dir";
        String s2= s1.replace("Türkiye","Ingiltere");
        System.out.println(s2);  //Ingiltere'nin baskenti Ankara'dir

        String s3=s1.replace('a','@');
        System.out.println(s3);    //Türkiye'nin b@skenti Ank@r@'dir

        //tek karakter icin char kullanmak daha mantiklidir!!

        //10)replaceAll()
        /*
        Verilen Stringdeki karakterleri istenilen karakterlere degistirmemizi saglar.
        char kullanilmaz.
        Regular Expressions kullanabiliriz (Regex)

         */

        String st1= "Kartal kalkar dal salkar.";
        System.out.println(st1.replaceAll("a","&"));

        //11)replaceFirst()
        /*
        Verilen String'deki istenilen ilk karakteri degistirir.

         */

        System.out.println(st1.replaceAll("al","on"));

        //12)trim()
        /*
        Verilen String'de kenarlarda bosluk varsa o bosluklari siler.
        Sadece kenardaki bosluklari siler ortadaki bosluklara dokunmaz.
         */

        String st2 ="    Java ogreniyorum.  ";
        String st3 = str2.trim();

        System.out.println("st2 = " + st2);
        System.out.println("st3 = " + st3);

        System.out.println(st2.length());
        System.out.println(st3.length());

        /*
        split()
        isEmpty()
        isBlank()
         */

        // split()      -Split makas görevi yapiyor
        //               verilen ayirmak istedigimiz yerdeki karakteri giriyoruz
        //               -String return eder
        //               " " --> tüm bosluuklari görüyor
        /*
            Oguzhan Parlak
            str.split(" ")[0] = Oguzhan
            str.split(" ")[1] = Parlak

        */
        //             0      1       2            3
        String str4= "Java hayati güzellestiriyor sence";

        String birinci = str4.split(" ")[0];
        String ikinci = str4.split(" ")[1];
        String ucuncu = str4.split(" ")[2];
        String dorduncu = str4.split(" ")[3];

        System.out.println(birinci);
        System.out.println(ikinci);
        System.out.println(ucuncu);
        System.out.println(dorduncu);

        System.out.println(dorduncu+" "+ ucuncu+ " "+ ikinci+ " "+ birinci);  //sence güzellestiriyor hayati Java

        String str5 = "Ankara";
        System.out.println(str5.split("r")[0]); //Anka
        System.out.println(str5.split("r")[1]);  //a   //r kayboldu bizce bi method sadece bosluklari ayirmada ideal

        //isEmpty()    ""
        //isBlank()    "" || " "


        String str6 = "";
        System.out.println(str6.isEmpty()); //true



    }
}

package simurg01.stringmanipulation;

import java.util.Scanner;

public class Q03ikinciCözüm {

    public static void main(String[] args) {

        Scanner input =new Scanner(System.in);
        System.out.println("Lütfen bir cumle giriniz.."); //Dunya bir gundur o da bugundur
        String cmle = input.nextLine();
        System.out.println(cmle);

        System.out.println("kelime giriniz : ");
        String c = input.nextLine();

        int a= cmle.indexOf(c);
        int b= cmle.lastIndexOf(c);

        if(a==-1){
            System.out.println("cumlede kullanilmamis");

        }else if(a==b){
            System.out.println("Bir kere kullanilmis");
        }
        else{
            System.out.println("cümlede birden fazla kullanilmis");
        }

    }
}

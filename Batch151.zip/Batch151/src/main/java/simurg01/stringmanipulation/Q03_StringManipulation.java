package simurg01.stringmanipulation;

import java.util.Scanner;

public class Q03_StringManipulation {
    public static void main(String[] args) {


        //Example : Kullanican bir cumle ve bir kelime isteyin, kelimenin cumledeki kullanimina bakarak
        // asagidaki 3 cumleden uygun olani yazdirin.
        // 1.Girilen kelime cumlede kullanilmamis
        // 2.Girilen kelime cumlede kullanilmis
        // 3.Girilen kelime cumlede 1'den fazla kullanilmis

        Scanner input =new Scanner(System.in);
        System.out.println("Lütfen bir cumle ve bir kelime giriniz.."); //Dunya bir gundur o da bugundur
        String cmle = input.nextLine();
        System.out.println(cmle);

        System.out.println("Lütfen bir cumle ve bir kelime giriniz.."); //Dunya bir gundur o da bugundur
        String cmle2 = input.nextLine();
        System.out.println(cmle2);


        boolean varMi = cmle2.indexOf("el")>-1;
        System.out.println(varMi);  //true

        Boolean birKereMi1 = cmle2.indexOf("el") == cmle2.lastIndexOf("el");
        System.out.println(birKereMi1); //true --> bir kere var   false --> birden fazla

        String result=varMi?(birKereMi1?"1 kere kullanilmis":"1 den cok kullanilmis"):"Kullanilmamis";
        System.out.println(result);


    }
}

package simurg01.stringmanipulation;

import java.util.Scanner;

public class C02_StringManipulation {

    public static void main(String[] args) {



        //********** concatenation()********\\

        /*
        concat()  : 1)Birden fazla String'i birlestirerek tek bir String haline getirmek icin kullanilir.
                    2)Iki sekilde kullanilir:
        //             i)+ (toplama) isareti ile
        //            ii)concat() methodu kullanarak

       */
        String s1 = "Bugun";
        String s2 = "Hava";
        String s3 = "Yagmurlu";
        System.out.println(s1+" "+s2+" "+s3);  //Bugun Hava Yagmurlu
        System.out.println(s1.concat(s2)); //BugunHava
        System.out.println(s1.concat(s2).concat(s3)); //BugunHavaYagmurlu
        System.out.println(s1.concat(" ").concat(s2).concat(" ").concat(s3)); //Bugun Hava Yagmurlu
        System.out.println(s1.concat(" ").concat(s2).concat(" ").concat(s3).concat("?")); //Bugun Hava Yagmurlu ?
        System.out.println(s1.concat(" "+s2+" "+s3)); //Bugun Hava Yagmurlu

        String s4 ="Bugun".concat(" ").concat(s2).concat(" ").concat(s3);
        System.out.println(s4);

        String s5 ="sey";
        String s6 ="her".concat(s5);
        System.out.println(s6);



         /*
        indexOf() : 1)Verilen String`de istenen karakterin kullanildigi ilk index'i döndürür.
                    2)int bir data döndürür.
        //1)char'in index'i sorgulanabilir
        //2)Parametre String olabilir
        //3)Olmayan karakter sorgulanirsa
        //4)Parametre kelime olabilir
        //5)Belli bir indexten sonrasi sorgulanabilir
         */

        String str = "Calisirsania, Java ogrenmek cok kolay";
        //1)char'in index'i sorgulanabilir
        System.out.println(str.indexOf('a')); //1
        //2)Parametre String olabilir
        System.out.println(str.indexOf("a"));  //1
        //3)Olmayan karakter sorgulanirsa
        System.out.println(str.indexOf("t"));  //-1
        //4)Parametre kelime olabilir
        System.out.println(str.indexOf("Java")); //14
        //5)Belli bir indexten sonrasi sorgulanabilir
        System.out.println(str.indexOf('a',11)); //15    11.indexi dahil eder !!


        //Example : Kullanicidan bir cümle ve bir harf isteyin, harfin cümlede var olup olmadigini yazdirin
        Scanner input = new Scanner(System.in);

        System.out.println("Lütfen bir cümle ve bir harf giriniz..");  //Dunya bir gundur o da bugundur.. 'z'
        String cmle = input.nextLine();
        System.out.println(cmle);

        int kontrol = cmle.indexOf('z');
        System.out.println(kontrol);    //-1

        boolean varMI= cmle.indexOf('u')>=0;  //>-1
        System.out.println("varMI = " + varMI);    //true

        boolean varMI2 =cmle.contains("u");
        System.out.println(varMI2);    //true
        System.out.println(cmle.contains("u"));  //true


        /*
        lastIndexOf() : 1)Verilen String`de istenen karakterin kullanildigi son index'i döndürür.
                        2)int bir data döndürür.
        //1)char'in index'i sorgulanabilir
        //2)Parametre String olabilir
        //3)Olmayan karakter sorgulanirsa
        //4)Parametre kelime olabilir
        //5)Belli bir indexten öncesi(tersten geldigi icin sonrasi) sorgulanabilir
         */

        String str2 = "Calisirsaniz, Java ogrenmek cok kolay";
        System.out.println(str2.length());
        //1)char'in index'i sorgulanabilir
        System.out.println(str2.lastIndexOf('a'));  //35
        //2)Parametre String olabilir
        System.out.println(str2.lastIndexOf("a"));  //35
        //3)Olmayan karakter sorgulanirsa
        System.out.println(str2.lastIndexOf("t"));  //-1
        //4)Parametre kelime olabilir
        System.out.println(str2.lastIndexOf("Java"));  //14  !! kelimeinin ilk harfinin indexini verir
        //5)Belli bir indexten sonrasi sorgulanabilir
        System.out.println(str2.lastIndexOf('a',11));  //8



    }
}

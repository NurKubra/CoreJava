package simurg01.stringmanipulation;

public class C03_StringManipulation {

    public static void main(String[] args) {

         /*
        equals() 1)Verilen iki stringin esit olup olmadigini karsilastirir
                 2)Boolean return eder

        equalsIgnoreCase() 1)equals() ile ayni islevi görür
                           2)büyük-kücük harf farkliligini yok sayar
                           3)boolean döndürür
         */

        String first = "Simurg";
        String second = "Simurg";

        if(first==second){
            System.out.println("First is equal to second");
        } else {
            System.out.println("First is not equal to second");
        }

        String third = new String("Simurg");
        String fourth = new String("Simurg");

        if(third.equals(fourth)){
            System.out.println("Third is equal to fourth");
        } else {
            System.out.println("Third is not equal to fourth");
        }

        String fifth = first;

        if(first==fourth){
            System.out.println("Fifth is equal to second");
        } else {
            System.out.println("Fifth is not equal to second");
        }

        //(==) ve Equals() methodları'nın ikisi de farklı 2 değeri karşılaştırmak için kullanılır.
        //(==) operator'ü 2 nesneyi karşılaştırırken, Equals() methodu nesnenin içerdiği string'i karşılaştırır.
        //Yani kısaca (==) operatörü 2 nesnenin referans değerlerini karşılaştırırken Equals() methodu sadece içeriği karşılaştırır.
    }
}

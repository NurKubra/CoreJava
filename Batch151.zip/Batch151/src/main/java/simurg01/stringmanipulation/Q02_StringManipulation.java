package simurg01.stringmanipulation;

import java.util.Scanner;

public class Q02_StringManipulation {

    public static void main(String[] args) {

        //Passwort olusturalim
        /*
        1.En az bir tane harf buyuk olmali
        2.En az bir tane sembol olmali
        3.En az bir tane kucuk harf olmali
         */

        Scanner input = new Scanner(System.in);
        System.out.println("Lütfen bir sifre giriniz.. ");



    }
}

package introduction.day03scanner;

public class Runner {

    //Runner Class`i Projeyi calistirmak icin kullanilir
    //Ve main method eklenir.

    public static void main(String[] args) {

        //Obje nasil olusturulur?
        //Class ismi + Object ismi + Atama operatorü + "new" + Constructor
        //Sifirdan yeni bir obje üretmek istedigimizde new eklemeliyiz.
        //"myCar" bizim yeni objemiz.

          Car              myCar          =           new        Car();

          //"new" keyword`u sifirdan yeni bir obje olusturmak icin kullanilir.
          //Constructor Java`da nesneleri olusturmak icin kullanilan özel bir methoddur.
          //Constructor = Class ismi + parantez ==> Car ()

        System.out.println(myCar.fiyat);
        System.out.println(myCar.model);


        myCar.hareket(); // Zaten Class`da sout un icinde oldugu ve void oldugu icin burda gerek yok.
        myCar.dur();     // Direk bu sekilde yazdirir.


        Student tomHanks = new Student();
        System.out.println("tomHanks.name = " + tomHanks.name);
        System.out.println("tomHanks.grade = " + tomHanks.grade);
        System.out.println("tomHanks.address = " + tomHanks.address);

        //alternatif olarak kullanilabilir.
        byte grade = tomHanks.grade;
        System.out.println("grade = " + grade);


        tomHanks.study();
        tomHanks.feed();

    }




}

package introduction.day03scanner;

import java.util.Scanner;

public class Scanner02 {

    //Kullanicidan ilk ismini ve soyismini alip ikisni ayni satirda ekrana yazdiriniz.
    public static void main(String[] args) {

        //1.Adim: Scanner class da obje olustur. (input: girdi)
        Scanner input = new Scanner(System.in);

        //2.Adim: Kullaniciya ne istedigimize dair mesaj veriniz.
        System.out.println("Lütfen ilk isminiyi giriniz..");
        String firstName = input.next();          //Tek kelimeli String icin !!

        System.out.println("Lütfen soyismnizi giriniz..");
        String lastName= input.next();


        System.out.println(firstName + " " + lastName);


    }


}

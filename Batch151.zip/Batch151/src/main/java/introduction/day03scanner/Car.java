package introduction.day03scanner;

public class Car {


    //Variable`lar olusturalim
    // Burda main method henüz yok cünkü obje üretmek icin gerekli kalibi olusturuyoruz!!
    public String model = "Corolla";
    public int fiyat = 20000;

    //Method`lar olusturalim
    //NOTE: "return type void" oldugunda method icinde "return" keyword`u kullanilmaz.
    //eger method yeni bir data uretmiyorsa sadece belli bir islem yapiyorsa return type`i void olur.
    //yeni bir deger üretmedigimiz zaman void kullaniliyoruz.
    //ya da retun`u olmayan data türü de diyebiliriz

    public void hareket() {
        System.out.println("Corolla hizli hareket eder....");
    }

    public void dur (){
        System.out.println("Coralla guvenli bir sekilde durur...");
    }

}

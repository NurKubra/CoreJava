package introduction.day03scanner;

import java.util.Scanner;

public class Scanner05 {

    public static void main(String[] args) {
        //Kullanicidan bir dikdortgenin iki kenar uzunlugunu aliniz
        //1) alanini hesaplayiniz ==> Kisa kenar * uzun kenar
        //2) cevresini hesaplayiniz ==> 2* Kisa kenar + 2* Uzun kenar
        Scanner input = new Scanner(System.in);

        System.out.println("Lütfen bir dikdörtgenin iki kenar uzunlugunu giriniz...");
        double shortSidee = input.nextDouble();
        double longSidee = input.nextDouble();

        System.out.println("Dikdörtgenin alani: "+ shortSidee * longSidee);
        System.out.println("Dikdörtgenin cevresi: " + (2*shortSidee +2*longSidee));


        //Hocanin yaptigi;
        Scanner inPut = new Scanner(System.in);
        System.out.println("Lutfen Dikdortgenin kisa kenar uzunlugunu giriniz..");
        double shortSide = inPut.nextDouble();
        System.out.println("Lutfen Dikdortgenin uzun kenar uzunlugunu giriniz..");
        double longSide = inPut.nextDouble();

         double alan = shortSide*longSide;
        System.out.println("Alan = "+ alan);          //tavsiye edilen
        System.out.println("Cevre = "+(2*shortSide+2*longSide));

    }
}

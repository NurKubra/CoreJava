package introduction.day03scanner;

public class Student {

    //Pasif ozellikler
    public String name = "Tom Hanks";
    public byte grade = 8;
    public String address = "Ankara";


     //aktif özellikler

    public void study(){

        System.out.println("Gunu gunune ders calisir..");

    }
    public void feed(){

        System.out.println("Saglikli beslenir..");
    }
}

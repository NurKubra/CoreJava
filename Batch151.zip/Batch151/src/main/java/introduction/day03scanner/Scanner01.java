package introduction.day03scanner;

// Javanin util kutuphnesinden scanner classs import edildi demektir.

import java.util.Scanner;

public class Scanner01 {

    public static void main(String[] args) {

        //Javada Scanner isminde icinde methodlarin oldugu bir class var. Onun methodlarini kullanabilmek icin obje olusturuyoruz
        //1. Adim: Scanner Class`tan bir obje olusutur
        Scanner input = new Scanner(System.in);

        //obje ismini input yaptik cünkü bu object kullanicidan alinan datayi benim kodlarimin icine koyacak.

        //2.Adim: Kullaniciya ne istedginize dair mesaj veriniz.
        System.out.println("Lütfen yasinizi giriniz..");

        //3. Adim:Uygun methodu kullanarak kullanicinin verdigi data`yi memory`e yerlestiriniz.
        byte age= input.nextByte();
        System.out.println(age);




    }
}


package introduction.day03scanner;

import org.example.Main;

import java.util.Scanner;

public class Scanner03 {
    //Kullanicidan adresini aliniz ve ekrana yazdiriniz.


    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Lütfen adreisinizi giriniz... ");

        String address = input.nextLine();   //Disardan alinan datayi sepete koyuyoruz. Hafizada yer etsin diye.
        System.out.println(address);


        //next() methodu kullanicidan tek kelimeli String`i almak icin kullanilir.
        // nextLine() methodu ise kullanicidan cok kelimeli String`i almak icin kullanilir.
    }

}

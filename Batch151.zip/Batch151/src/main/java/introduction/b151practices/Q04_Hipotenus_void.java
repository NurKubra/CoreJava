package introduction.b151practices;

public class Q04_Hipotenus_void {



}

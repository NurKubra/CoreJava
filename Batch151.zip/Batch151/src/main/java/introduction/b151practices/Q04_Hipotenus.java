package introduction.b151practices;

public class Q04_Hipotenus {




    public static void main(String[] args) {

        //Hipotenüs hesaplayan bir kod yazınız
        //Math.sqrt(16)  ==> parantez icinde yazan degerin karakökünü alir.


       double hipotenus = hipotenusHesapla(3,4)*3;
        System.out.println(hipotenus);

        //ya da direk ;
        //System.out.println("hipotenusHesapla(3,4) = " + hipotenusHesapla(3, 4));

    }

    public static double hipotenusHesapla(double dikkenar1, double dikkenar2) {

        double hipotenus = Math.sqrt(dikkenar1*dikkenar1+dikkenar2*dikkenar2) ;
        return hipotenus;

        //double bize uretilcek datanin cinsini söyler.
        //void yazarsak bir data dönmeyecek sadece verilen datayi yazdircak.
    }
}

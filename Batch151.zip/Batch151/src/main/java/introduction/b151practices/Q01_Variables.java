package introduction.b151practices;

public class Q01_Variables {

    public static void main(String[] args) {


        //data type + variable name + atama operatörü + data + noktali virgül
        //Burdan degeri degistirince her yerden degisiyor.
        //primitive data type`lar method icermezler.
        //Bir Variable(Degisken) baslat (degiskenin nasil bir yapi oldugunu söyler)

        int age = 15;
        int number = 43;
        String isim = "Ali";

        System.out.println(age);                         //sout
        System.out.println("age = " + age);              //soutv
        System.out.println("number = " + number);
        System.out.println("isim = " + isim);
        System.out.println(isim);

        System.out.print(age);
        System.out.print(number);
        System.out.println(isim);                         //ln`siz print en alttaki bir sonraki satira yan yana yazdririr.
        //sout yazilimcilarin kodlarinin calisip calismadigini
        //kontrol etmek icin yazdirmasini saglar.
        //Variable degerini kopyala!

        int myAge = age;                                   // Age`in degerini myAge`e atamis olduk.
        System.out.println("myAge = " + myAge);
        String onunIsmi = isim;
        System.out.println("onunIsmi = " + onunIsmi);


        //Ayni satirda coklu Variable deklere et

        int year = 2022, month = 5, day = 15;              //Genelde cok kullanilan bir sey degil ama bu sekilde yazilabilir.
        System.out.println("month = " + month);

        //Bir Variable degerini güncelle

        year = 2023;                                        //Önce 2022 sonra 2023 olarak yazdirir.
        System.out.println("year = " + year);               //ayni body ya da scope icinde bir kere deklere etmek yeterli.
        //Yeni deger atamak icin yeniden int yazmak gerekmez.

        year = 2030;
        System.out.println("year = " + year);                //sonraki bütün islemlerde en son atanan deger kullanilir.

        isim = "Veli";
        System.out.println("isim = " + isim);
        System.out.println("onunIsmi = " + onunIsmi);       //Burda onunIsmi hala Ali olarak kalir. Cünkü onunIsmi konteksini de
        //güncellememiz gerekiyordu.

        onunIsmi = isim;
        System.out.println("onunIsmi = " + onunIsmi);        //Burda yeniden güncelleme yaptigimiz icin onunIsmi de artik Veli oldu.


        //Bir Variable deklere et: x
        double x;

        //Bir Variable baslat : y
        double y = 55.6;

        //Baska bir variable baslat : z
        double z = 10;

        //x degiskenini y degiskeni ile baslat
        x = y;

        //x degiskenini güncelle
        x = 15.3;

        //Degiskenleri yazdir
        System.out.println("x = " + x);     //x=15,3
        System.out.println("y = " + y);     //y= 55.6
        System.out.println("z = " + z);     //z=10.0

        /* x`i degistirdikten sonra y ilk atama ila kalir. Yeniden guncellernirse
        yani 2. kez x= y; yazilirsa y`nin degeri de gucellenir.
         */
    }
}

package introduction.b151practices;

public class Q02_KullaniciBilgileri {

    public static void main(String[] args) {

        /* firstname, lastname, age, height ve weight degiskenlerini konsola asagidaki gibi yazdiran bir kod
        yaziniz:
            First Name: ...
	 		Last Name: ...
	 		Age: ...
	 		Height: ...
	 		Weight: ...
	 Not: Sadece bir adet "System.out.println(); kullanınız.
	 */

        String firstName = "Kübra";
        String lastName  = "Sen";
        byte age = 27;
        double height = 1.65;
        double weight = 56.5;

        System.out.println("First Name: " + firstName + "\nLast Name: " + lastName + "\nAge: " + age +
                "\nHeight: "+ height + "\nWeight: "+ weight );



        //\n bir alttaki satira gecmek icin kullanilir.

    }
}

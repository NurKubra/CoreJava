package introduction.b151practices;

public class Q01_VariablesTEKRAR {

    public static void main(String[] args) {

        //data type + variable name + atama operatörü + data + noktali virgül

        int age = 15;
        int number = 43;
        String isim = "Ali";

        System.out.println(age);                    //sout
        System.out.println("age = " + age);         //soutv
        System.out.println("number = " + number);
        System.out.println("isim = " + isim);
        System.out.println(isim);

        System.out.print(age);
        System.out.print(number);
        System.out.print(isim);

        //ln´siz print alttaki bir sonraki satira yan yana yazdirilir.

        int myAge = age ;
        System.out.println("myAge = " + myAge);
        String onunIsmi = isim;
        System.out.println("onunIsmi = " + onunIsmi);


    }
}

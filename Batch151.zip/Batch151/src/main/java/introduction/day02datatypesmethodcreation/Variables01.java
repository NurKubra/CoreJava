package introduction.day02datatypesmethodcreation;

public class Variables01 {

    /*
    javada temelde iki tip data vardir;
    1)primitive data type
      char, boolean, byte, short, int, long,float, double
     - 4 tanesi tam sayilari muhafaza etmek icin.

    2)non-primitive data type
      String
     */

    /*
    Note 1:primitive data type`lari java olusturmustur, biz olusturmayiz
    Note 2:primitive data type`larin isimlerinde sadece kucuk harf kullanilir.
    Note 3:primitive datalar data type`larina göre memory`de farkli farkli yer kaplar.
    Note 4:primitive data`lar iclerinde sadece sizin atadiginiz degeri barindirir.
     */

    /*
    non-primitive data types:
       String
     Note 1: Ornegin String non-primitive bir data type ornegidir.
     Note 2: Uretilen her bir class ayni zamanda bir non.primitive data type`dir.
     Bu yüzden non-primitive data type`lar sinirsiz sayidadir.
     Note 3:Non-primiitve data type`larin isimleri buyuk harfle baslar.
     Note 4:Non- primitive data type`larin tamami icin java memeory de ayni miktarda yer ayirir.

     //Üretilen her bir class ayni zamanda bir non-primitive data type`dir.
     //non-primitve data type`larin sayisi sinirsizdir.
     //Non-primitive data`lar ayni zamanda bir class`dir bu yüzden String buyuk harfle yazilir.
     */


    public static void main(String[] args) {

        // Ornek 1:Sehir ismi icin bir variable olusturun ve onu ekrana yazdirin.

        String cityName = "Ankara" ;
        System.out.println(cityName);

        int a = 13;
        //non-primitive de;
        //Ankara ==> ANKARA Tum karakterler buyuk harfe donusuturen method var
        //Ankara ==> 6 karakterin sayisini veren method var




        /*Interview sorusu ;
        "Primitive ve non-primitive data type`lar arasindaki fark nedir?"
           Method farki vardir.
          1)"primitive"ler sadece bizim atadigimiz degeri icerir;
            "non-primitive"ler bizim atadigimiz deger ve methodlar icerir.
          2)"primiitve"ler kucuk harfler baslar, "non-primitive"ler buyuk harfle baslar.
          3)"primitive"leri java uretmistir; 8 tanedir.
            "non-primitive"leri java ve developerlar uretebilir bu yüzden sinirsiz sayidadir.
          4)"primitive"ler memory de data type`ine gore yer kaplar.
            "non-primitive"ler icin java memory de hep ayni buyuklukte yer kaplar.

         //class`larin icindeki pasif ozellikler variable yani primitive data turleri diyebili miyiz ? evet



         //Primitive`ler tam pasifdir (variable icerir). Ama Non primitiveler hem pasif (varibable icerir) hem de aktiftir.
         */
    }
}

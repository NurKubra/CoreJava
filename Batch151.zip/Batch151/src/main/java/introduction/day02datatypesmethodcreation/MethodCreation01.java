package introduction.day02datatypesmethodcreation;

public class MethodCreation01 {

       /*
       Javada method nasil olusturulur

       1)main Method`un disinda olusturulur
       2)Access Modifier + return type + method ismi + () + {}

       // Parametreler parantez icine yazilir.
       Olusturulan methodlar nasil kullaniliir?

       1) main method`un icinden kullanilir.
       2) methodun ismi + () yazin
       3) islem yapcaginiz parametreler parantezin icine koyulur.
        */

    public static void main(String[] args) {
        //main method class a aittir bu yuzden statiktir.
        //Main method icinde bir sey yapilcaksa statik yazilir.
        //sadece statik olanlarin islemini yapar..

        //Ornek1
        int sonuc = toplamaYap(30, 60);  // Toplama yap methodunu sonuc sepeti icine koyduk (int cinsinden).
        System.out.println(sonuc);

        //Ornek2
        long carpmaSonuc = multiply(3, 5);
        System.out.println(carpmaSonuc);

        //Ornek3
        int üclüSonuc = firstTwoMultiplyThirdAdd(2, 5, 8);
        System.out.println(üclüSonuc);

        //Ornek4
        double kup = getCube(3.5);
        System.out.println(kup);

        System.out.println(getCube(3.5)); //Alternatif kullanim; Sepete koymadan direk de yazdirabiliriz!!!!

        //Ornek5
        print("Hello World");
        print("Levent");

    }

    //Ornek 1:Toplama islemi yapan bir method olusturunuz.

    public static int toplamaYap(int a, int b) {   //static bir yapi icinde kullanilcaksa statik eklenir!!

        return a + b;

        // return yeni uretilen datayi getirmek icin

    }

    //Ornek 2: 2 sayiyi carpma islemi yapan bir method olusturunuz.

    protected static long multiply(int a, int b) {

        return a * b;

    }

    // Ornek 3: Verilen 3 sayidan ilk ikisini carpan ve sonucunu sayi ile toplayan bir method olusturunuz.

    private static int firstTwoMultiplyThirdAdd(int a, int b, int c) {

        return a * b + c;


    }
    //Ornek 4: Verilen bir ondalik sayinin küpünü hesaplayan method olustutunuz.
    //Ondalik sayi oldugu icin DOUBLE kullaniyoruz.
    //NOTE: ACCESS MODIFIER`I "DEFAULT " YAPMAK ISTERSENIZ ACCESS MODIFIER YAZILMAZ!!
    //default static double getCube(double a) {} olmuyor
     static double getCube(double a) {

        return a * a * a;


    }

    //Ornek 5: Girilen bir kelimeyi ekrana yazdiran bir method kullaniniz.
    //VOID kullandik cunku YENI bir data ÜRETMIYOR sadece bir is yapiyor.
    //Return Type i "VOID" oldugu zaman "RETURN" kullanmiyoruz.
    //Print methodu bir is yapiyor
    //data uretmedigi icin sout asagi yazdik
    public static void print (String str){  //return type`i olmayan bir method!

        System.out.println(str);            //str yerine baska bir sey de kullananilabilir.


    //shitf+ F10 ==> run

        //OBJELERE AKTIF OZELLIK KAZANDIRDIK.
    }
}


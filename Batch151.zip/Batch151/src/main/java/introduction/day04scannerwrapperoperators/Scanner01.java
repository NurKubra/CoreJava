package introduction.day04scannerwrapperoperators;

import java.util.Scanner;

public class Scanner01  {

    public static void main(String[] args) {

        //Kullanicidan alacaginiz 5 basmaakli bir sayinin ilk iki ve son iki basamagindaki rakamlarin
        //toplamini yazdiran kodu yaziniz.

        //Note: Bir sayiyi 10`a bölersek kalan bize son rakami, bölüm ise geriye kalan rakamlari verir.

        //JAVA da bir tamsayiyi bir tamsayiya bolerseniz java kesinlikle tamsayi yapar.
        //Java sonucu nasil tam sayi yapar? ;Ondalik kismi iptal eder. Java yuvarlama yapmaz.
        // (3867.1 ) sondaki 1 i iptal eder.

        Scanner input = new Scanner(System.in);

        System.out.println("Lütfen 5 basamakli bir sayi giriniz..");  //38671
        int number = input.nextInt();
        // Bir sayinin son rakamini alabilmek icin o sayiyi 10`a bölüp kalani almaliyiz.
        // %==> MODULUS OPERATOR solunda bulunan sayinin saginda bulunan sayiya bölümünden kalani verir.
        // Dolayisiyla %10 her zaman bize birler basamginda bulunan sayiyi verir.
        // Bir tamsayiyi bir tamsayiya bolersniz java sonucu kesinlikle bir tamsayi yapar
        // Java bu durumda yuvarlama yapmaz ondalikli kismi iptal eder
        // dolayisiyla bir tamsayiyi 10`a bölersek birler basamagini silmis olur.


        //Son rakami al
        int lastDigit = number%10;
        //sayi kücült
        number = number /10;

        //sondan ikinci rakami al
        int lastSecondDigit = number%10 ;
        //sayi kücült
        number = number /10;

        //sondan ücüncü rakami al
        int lastThirdDigit = number%10;
        //sayi kücült
        number = number/10;

        //sondan dördüncü rakami al
        int lastFourtDigit = number%10;
        //sayi kücült
        number= number/10;

        //sondan besinci rakami al
        int lastFifithDigit = number%10;
        //sayiyi kücült
        number =number/10;

        System.out.println(lastDigit+lastSecondDigit+lastFourtDigit+lastFifithDigit);
    }
}

package introduction.day01variables;

public class Variables01 {

    public static void main(String[] args) {

          //java bu satiri okumaz. Kenidmize veya baskasina aciklamadir.
          /*
          * java bu satirlari da okumaz!
          */

          // Variable olusturma:
          // data type + variable name + atama operatörü + data + noktali virgül

        int            age                 =           13         ;


          /* java cümlesi = Statement
           * java`da "=" assigment operator (Sagdaki degeri alir soldaki kutunun icine atar (koyar.))
           * java`da esittir demek "==", Matematikte "=" ==> java`da "=="
           * Eger variable declaration yapar, assigment yapmazsaniz java kendi Default degerlerini yukler
           * Default deger SAYILAR icin  SIFIRDIR 0`dir.
           * Data Type + variable name ==> Variable declaration
           * Assigment operator(atama operatorü) + variable degeri ==> Assignment
           */

           /* javada temel iki tip data vardir ;
            1) Primitive data type (ilkel):
               char, boolean, byte, short, int, long, float, double
            2) Non-Primitive data type (ilkel olmayan):
               String
            */


            // Ornek 1: Ogrenci ismi icin variable olusturunuz ve deger olarak Ali Can atayiniz
            // String`lere verilen degerler daiam "cift tirnak" icinde olmalidir.
            // Variable kücük harfle baslar.

        String studentName  = "Ali Can";
             // Stringler icin "default value" "null"dir.
             // null demek 0 demek degildir, cünkü 0 da coding de bir degerdir.
             // null ==> ici bos obje ya da bos küme demektir.
             // {}


             // char data type:
             // tek bir karakter icin kullanilir. Orn==> A, x, 5,? ...vs
             // Ornek 2: char data type`inde bir ismin ilk harfi olarak bir variable olusturunuz ve bir deger atayiniz

        char isminIlkHarfi  = 'A' ;

             // isim atarken uzunluk önemli degil, aciklayici olmasi önemli !!
             // char data type`inde degerler 'tek tirnak' icine konulmalidir.
             // 5 normalde bir tam sayidir ama tirnak icinde char olmaktadir.
             // Coklu karakterlerde Cift Tirnak (String) ==> "  ",
             // Tek karakterlerde tek tirnak (char) ==> '  ' kullanilir.


             //boolean data type:
             //boolean lar iki farkli deger alabilirler true( dogru) veya false (yalnis)
             //Ornek 3 : boolean data type`in de emekli misin sorusu icin bir variable olusturun ve false degerini atayn.

        boolean emeklimisin = false ;  // Kucuk ya da buyuk harfle yazilmaz



              //byte data type:
              //tam sayilar icindir. Hafizada 1 byte yer kaplar.
              //byte -128`den +127`e (dahil) kadar tam sayi degerleri icin kullanilabilir.
              //byte: en kücük byte = -128
              //      en büyük byte =  127
              //Ornek 4: byte data type`inde ogrenci yasi icin bir variable olusturunuz ve deger atayiniz.

        byte ogrenciYasi = 27 ;
        byte studentAge  = 23 ;   // fazla yazarsak kabul etmez max 127 olmali!!



              //short data type:
              //Tam sayilar icindir ve hafizada 2 byte yer kaplar.
              // short : -32768 ile 32767 icin kullanilir.
              //Ornek 5:

        short okuldakiÖgrenciSayisi = 1300 ;
              // Tam Sayilarda tek ya da cift tirnak kullanmiyoruz.


             //int data type:
             //tam sayilar icindir. Hafizada 4 byte yer kaplar
             //int: -2,147,483,648 ile 2,147,483,647 arasindaki sayilar icindir
             //Ornek 6: ulke nufüsu icin bir varibale olusturunuz ve deger atayiniz.

        int ulkeNufusu = 13000000 ;
        int countryPopulation = 1700000 ;


             //long data type:
             //tam sayilar icindir hafizada 8  byte yer kaplar
             //long: -9,223,372,036,854,775,808 ile 9,223,372,036,854,775,807 arasindaki sayilar icindir.
             //Ornek 7:Insan vucüdundaki hucre sayisi icin variable olusturup deger atamasi yapiniz.

        long cellNummerInHumanBody = 787474343858L ; // java hafizayi korumak icin bu sayiyi int kabul ediyor
                                                     // ve hata veriyor!
                                                     // Bunu bilerek yaptigimizi göstermek icin sayi sonuna L konur.

             // Bir deger long ise sonuna "l" ya da "L" (tercih edilir) konulur.
             // Eger long`a atadiginiz deger int`lerin araliginda ise sonuna "L" koymaya gerek yok.
             // long dememize ragmen sonuna L koymazsak java bu degeri int araliginda ise int kabul eder.
             // L koymadigimizda hata vermiyorsa int`tir.

        long weight = 1234567 ; // int`lerin araligi ise sonu L koymaya gerek yoktur.



            //float data type:
            //float virgüllü sayilar (Decimal numbers ==> ondalikli sayilar ) icin kullanilir.
            // fiyatlandirma icin tercih edilir (12,99)

            //Ornek 8: Gomlek ve ayakkabi fiyatlari icin iki tane variable olusturup toplam fiyati ekrana yazdiriniz.
            //java ondalikli sayilari yani Decimal numbers `i otomatik olarak double kabul eder
            //siz data type`ini float yazarsaniz hata verir
            //float olmasinda israr ediyorsaniz sonuna "F" ya da "f" koymalisiniz
            //float memory de 4 byte yer kaplar, double 8 byte yer kaplar! (daha cok yer kaplamasina ragmen öyle kabul edilir)

        float gomlekFiyati = 12.99F ;
        float ayakkabiFiyati = 15.99F ;


        System.out.println(); // Sistemde var olan bilgileri disarda yazdir.
        System.out.println(gomlekFiyati + ayakkabiFiyati);
        //  System.out.println(); kodu parantez icine yazdiklarimiz ekrana yazdirir.

        int a = 12;
        int b = 13;
        System.out.println(a + b);
        System.out.print(a+b);   // sonuc 25 dir. Parantez icinde birlikte olduklari icin
        System.out.print((a)+(b)); // yine toplar


        //System.out.println(); ekrana yazdirir ve "pointer" i bir sonraki satira koyar
        //System.out.print(); ekrana yazdirir ve "pointer" i ayni satirda tutar

        int c =313 ;
        int d =314;
        System.out.print(c);
        System.out.print(d);
        // iki sayiyi yan yana cikarir : 313314 olarak ikisini ayni satirda tutar

        //double data type:
        //double memory de daha fazla yer kaplar, virgülden sonraki rakam daha fazla alir
        //double virgullu sayilar(Decimal numbers ==> Ondalik sayilar) icin kullanilir. Ama hassas degerler icin.

        //Ornek 9: Hucre agirligi ve Amip in agirligi icin iki tane variable olusturunuz ve agirliklari
        //ekrana yazdiriniz.

        double weightCell = 0.00000000000112;
        double weigthAmip = 0.00000000000023;

        System.out.println(weightCell- weigthAmip);






    }
}


